(quick note you can copy the file location thing and paste it to the file explorer if you are lazy like me)


How to install SAR or SourceAutoRecord to portal 2! First navigate to 




C:\Program Files (x86)\Steam\steamapps\common\Portal 2


then drag your        sar.dll     file to the common folder which is            C:\Program Files (x86)\Steam\steamapps\common\Portal 2 



(optional) if you already have an autoexec.cfg then skip this, but if you want my autoexec.cfg then follow these steps


First head to  



C:\Program Files (x86)\Steam\steamapps\common\Portal 2\portal2




then head to 



C:\Program Files (x86)\Steam\steamapps\common\Portal 2\portal2\cfg



then drag the autoexec.cfg file to there.