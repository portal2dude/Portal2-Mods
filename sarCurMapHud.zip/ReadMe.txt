(READ THIS FIRST. THIS WORKS ONLY WITH THE PLUGIN CALLED "Source Auto Record" OR FOR SHORT "SAR" AND EXTRACT BEFORE STARTING TO INSTALL THE MOD TO PORTAL2)




For the         sarCurMapHud Which basically let you view what map you are in with the sar_hud command        for   mod to work you need to follow these steps. First go to        

C:\Program Files (x86)\Steam\steamapps\common\Portal 2


Or where ever you got your portal 2 common folder at.
Then after enter 



C:\Program Files (x86)\Steam\steamapps\common\Portal 2\portal2




then after you have to go to 







C:\Program Files (x86)\Steam\steamapps\common\Portal 2\portal2\cfg





then you can drag your mod in there