How to setup DifferentCoreColors Mod!

first head to 


C:\Program Files (x86)\Steam\steamapps\common\Portal 2



after head to 



C:\Program Files (x86)\Steam\steamapps\common\Portal 2\portal2_dlc2



then after you wanna head to 




C:\Program Files (x86)\Steam\steamapps\common\Portal 2\portal2_dlc2\scripts




then




C:\Program Files (x86)\Steam\steamapps\common\Portal 2\portal2_dlc2\scripts\vscripts



then drag SameShellColorAsEyeColorForAllCores.nut



then if you want it to work it self then copy this link and paste it to your browser 



https://github.com/portal2dude/Portal2-Mods/blob/main/SourceAutoRecord(WithMyAutoexec).zip                      


then install the mod then open the       



autoexec.cfg



sar.dll


then after



if you only want the DifferentCoreColors mod then  (quick note that everything inside of the autoexec.cfg will work as long as you install SAR correctly)



open the 



autoexec.cfg



then delete everything else but the 


exec srconfigs/srconfigs
plugin_load sar
sar_on_load script_execute SameShellColorAsEyeColorForAllCores



remember if you are typing it just remember that there are lines on each command.


now how to install Source Auto Record or SAR For short




first head to 




C:\Program Files (x86)\Steam\steamapps\common\Portal 2


then drag 


sar.dll to 



C:\Program Files (x86)\Steam\steamapps\common\Portal 2



then head to 




C:\Program Files (x86)\Steam\steamapps\common\Portal 2\portal2




then after head to




C:\Program Files (x86)\Steam\steamapps\common\Portal 2\portal2\cfg




then drag the 





autoexec.cfg





C:\Program Files (x86)\Steam\steamapps\common\Portal 2\portal2\cfg




now launch the game and enjoy!




